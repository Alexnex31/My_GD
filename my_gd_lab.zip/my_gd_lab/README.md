# My_GD verification lab

Tools used to verify the claims in PLAN.md. Two halves:

- `legacy/`: experiments, a search bot and a differential tester that link the
  **real game sources** of the legacy commit. They need a display and audio, so
  they run under Xvfb with OpenAL's null driver.
- `core_prototype/`: a pure-C prototype of the new simulation core described in
  PLAN.md (no CSFML), with switches for every legacy quirk, plus a headless bot.

## Setup (Ubuntu/Debian)

    sudo apt install libcsfml-dev xvfb
    git -C /path/to/My_GD worktree add ../My_GD-legacy legacy-physics   # or any checkout of 3f625f2

## Run

    make LEGACY=../My_GD-legacy run-legacy   # experiments E1-E6, bot on the 7 levels, legacy-vs-prototype diff
    make LEGACY=../My_GD-legacy run-core     # jump arcs + bot on the prototype (parity, then everything new at 240 Hz)

The legacy tools run with the legacy checkout as working directory (they need
`res/` and `levels/`). The bot writes `solN.txt` (winning input, one char per
frame) there, and `diff` reads them back. exp3/exp4 create and delete a
temporary `levels/level8` / `levels/level9`.

## nsolve switches

    bin/nsolve LEVEL teleport lock propspikes newcoll centered ticks_per_frame [jump_v [cube_g]]

- `teleport`: legacy player teleport when entering a ship portal
- `lock`: legacy "can't jump while inside a cube portal"
- `propspikes`: spike hitbox proportional to size (legacy is fixed 40 px wide)
- `newcoll`: previous-position + inner-hitbox block resolver (legacy is min-penetration)
- `centered`: ship corridor centered on the portal (legacy: portal.y-400 .. portal.y+450)
- `ticks_per_frame`: 1 = 60 Hz, 4 = 240 Hz
- `jump_v`, `cube_g`: in legacy per-frame units (defaults 26 and 1.4)

Parity: `1 1 0 0 0 1`. Everything new at 240 Hz with matched arc: `0 0 1 1 1 4 25 1.348611`.

## modes_proto.c

Prototype for FEATURES.md (UFO, wave, ball, direction-aware resolver, 240 Hz). `gcc -O2 core_prototype/modes_proto.c -o modes_proto -lm && ./modes_proto`
