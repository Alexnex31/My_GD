/* Measures the cube jump arc of the prototype core at several tick rates.
   usage: apex path/to/a/level/with/a/flat/start */
#include "sim.h"
#include <stdio.h>

static void apex(const char *level, int tpf, float jv, float g, const char *label)
{
    sim_t s;
    float miny = 800.0f;
    long t0;

    g_flags = (sim_flags_t){1, 1, 0, 0, 0, tpf, jv, g};
    if (sim_load(&s, level) != 0) {
        printf("cannot open %s\n", level);
        return;
    }
    sim_reset(&s, 350, 800);
    s.p.grounded = true;
    t0 = s.tick;
    sim_tick(&s, 1);
    while (!s.p.grounded && s.p.alive && !s.complete && s.tick - t0 < 4000) {
        sim_tick(&s, 0);
        if (s.p.pos.y < miny)
            miny = s.p.pos.y;
    }
    printf("%-28s apex %.1f px, airtime %.3f s, distance %.0f px\n", label, 800 - miny,
        (s.tick - t0) / (60.0 * tpf), (s.tick - t0) * 12.5 / tpf);
    sim_free(&s);
}

int main(int argc, char **argv)
{
    const char *level = argc > 1 ? argv[1] : "levels/level3";

    apex(level, 1, 0, 0, "60 Hz (legacy)");
    apex(level, 4, 0, 0, "240 Hz, same constants");
    apex(level, 4, 25.0f, 4855.0f / 3600.0f, "240 Hz, v 1500, g 4855");
    return 0;
}
