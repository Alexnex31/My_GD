/* FEATURES.md prototype: input edges, mode table, direction-aware resolver, UFO, wave, ball at 240 Hz.
   Mode portals never change gravity. Build: gcc -O2 modes_proto.c -o modes_proto -lm */
/* Prototype of FEATURES.md sections 1, 4-7 at 240 Hz: input edges, mode table,
   direction-aware resolver, UFO, wave, ball, corridors; plus measurements and a bot. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdint.h>
#include <math.h>
#define TR 240.0f
#define PT(v) ((float)(v) / TR)
#define PT2(a) ((float)(a) / (TR * TR))
#define GROUND 850.0f
#define SCROLL 750
enum { CUBE, SHIP, UFO, WAVE, BALL, NM };
typedef struct { float x, y, w, h; } rect_t;
typedef struct { int type; rect_t r, hb; int mode; bool trig; } obj_t;   /* 0 block 1 spike 2 portal */
typedef struct { float x, y, py, vy; int mode, dir, buf; bool grounded, alive; } pl_t;
typedef struct { obj_t o[256]; int n; float end; pl_t p; long tick; bool corr; float top, bot; bool done; } sim_t;
typedef struct { bool held, pressed; } in_t;
static const char *NAMES[NM] = {"cube", "ship", "ufo", "wave", "ball"};
static const float HALF[NM] = {50, 50, 50, 15, 50}, INNER[NM] = {20, 20, 20, 15, 20};
static const bool CORR[NM] = {0, 1, 1, 1, 1}, KILL[NM] = {0, 0, 0, 1, 0};
/* constants (px/s, px/s^2) */
#define CUBE_G 4855
#define CUBE_V 1500
#define CUBE_MAX 2580
#define SHIP_G 5580
#define SHIP_T 12600
#define SHIP_MAX 1680
#define UFO_G 3600
#define UFO_V 1050
#define UFO_MAX 1300
#define BALL_G 4200
#define BALL_V 350
#define BALL_MAX 2000
#define BALL_BUF 8
static bool ov(rect_t a, rect_t b) { return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y; }
static rect_t box(float x, float y, float h) { return (rect_t){x - h, y - h, 2 * h, 2 * h}; }
static void input(pl_t *p, in_t in)
{
    switch (p->mode) {
    case CUBE: if (in.held && p->grounded) { p->vy = PT(CUBE_V); p->grounded = false; } break;
    case SHIP: if (in.held) p->vy += PT2(SHIP_T); break;
    case UFO: if (in.pressed) p->vy = PT(UFO_V); break;
    case WAVE: p->vy = in.held ? PT(SCROLL) : -PT(SCROLL); break;
    case BALL:
        if (in.pressed) p->buf = BALL_BUF;
        if (p->buf > 0 && p->grounded) { p->dir = -p->dir; p->vy = -PT(BALL_V); p->grounded = false; p->buf = 0; }
        if (p->buf > 0) p->buf--;
        break;
    }
}
static void integ(pl_t *p)
{
    float g = 0, mx = 1e9f;
    if (p->mode == CUBE) { g = CUBE_G; mx = CUBE_MAX; }
    if (p->mode == SHIP) { g = SHIP_G; mx = SHIP_MAX; }
    if (p->mode == UFO) { g = UFO_G; mx = UFO_MAX; }
    if (p->mode == BALL) { g = BALL_G; mx = BALL_MAX; }
    if (p->mode != WAVE) { p->vy -= PT2(g); if (p->vy > PT(mx)) p->vy = PT(mx); if (p->vy < -PT(mx)) p->vy = -PT(mx); }
    p->y -= p->dir * p->vy;
}
static void surfaces(sim_t *s)
{
    pl_t *p = &s->p; float h = HALF[p->mode];
    float floor_y = s->corr ? s->bot : GROUND;                    /* screen-bottom surface */
    if (floor_y > GROUND) floor_y = GROUND;
    if (p->y + h > floor_y) { p->y = floor_y - h; if (p->dir > 0) { if (p->vy < 0) p->vy = 0; p->grounded = true; } else if (p->vy > 0 && p->mode != WAVE) p->vy = 0; }
    if (s->corr && p->y - h < s->top) { p->y = s->top + h; if (p->dir < 0) { if (p->vy < 0) p->vy = 0; p->grounded = true; } else if (p->vy > 0 && p->mode != WAVE) p->vy = 0; }
}
static void block(pl_t *p, obj_t *o)
{
    float dir = p->dir, h = HALF[p->mode];
    rect_t outer = box(p->x, p->y, h), inner = box(p->x, p->y, INNER[p->mode]);
    float fs = dir > 0 ? o->hb.y : o->hb.y + o->hb.h, cs = dir > 0 ? o->hb.y + o->hb.h : o->hb.y;
    float pf = p->py + dir * h, ph = p->py - dir * h;
    if (!ov(outer, o->hb)) return;
    if (KILL[p->mode]) { p->alive = false; return; }
    if (p->vy <= 0 && (fs - pf) * dir >= -12.0f) { p->y = fs - dir * h; p->vy = 0; p->grounded = true; return; }
    if (CORR[p->mode] && p->vy >= 0 && (ph - cs) * dir >= -12.0f) { p->y = cs + dir * h; p->vy = 0; return; }
    if (ov(inner, o->hb)) p->alive = false;
}
static void portal(sim_t *s, obj_t *o)
{
    pl_t *p = &s->p;
    p->mode = o->mode;
    s->corr = CORR[o->mode];
    if (s->corr) {
        float c = o->r.y + o->r.h / 2;
        s->top = c - 425; s->bot = c + 425;
        if (s->bot > GROUND) { s->bot = GROUND; s->top = GROUND - 850; }
    }
    p->grounded = false;                          /* gravity_dir is never changed by a mode portal */
}
void tick(sim_t *s, in_t in)
{
    pl_t *p = &s->p;
    if (!p->alive || s->done) return;
    input(p, in);
    p->py = p->y; s->tick++;
    p->x = 350 + s->tick * PT(SCROLL);
    integ(p);
    if (s->tick * PT(SCROLL) >= s->end) { s->done = true; return; }
    p->grounded = false;
    surfaces(s);
    if (!s->corr && (p->y < -1000 || p->y > 2000)) { p->alive = false; return; }   /* out of bounds (no camera here) */
    for (int pass = 0; pass < 3; pass++)
        for (int i = 0; i < s->n && p->alive; i++) {
            obj_t *o = &s->o[i];
            if (o->type != pass || o->r.x > p->x + 60 || o->r.x + o->r.w < p->x - 60) continue;
            rect_t outer = box(p->x, p->y, HALF[p->mode]);
            if (pass == 0) block(p, o);
            else if (pass == 1 && ov(outer, o->hb)) p->alive = false;
            else if (pass == 2 && !o->trig && ov(outer, o->hb)) { o->trig = true; portal(s, o); }
        }
}
static void reset(sim_t *s) { s->p = (pl_t){350, 800, 800, 0, CUBE, 1, 0, true, true}; s->tick = 0; s->corr = false; s->done = false; for (int i = 0; i < s->n; i++) s->o[i].trig = false; }
static void load(sim_t *s, const char *txt, bool mirror, float axis)
{
    char buf[4096]; strcpy(buf, txt); s->n = 0; s->end = 100;
    for (char *l = strtok(buf, "\n"); l; l = strtok(NULL, "\n")) {
        char t[16], m[16] = ""; float x, y; int sz;
        if (sscanf(l, "%15s %f %f %d %15s", t, &x, &y, &sz, m) < 4) continue;
        obj_t *o = &s->o[s->n]; memset(o, 0, sizeof *o);
        float w = sz * 50.0f, h = strcmp(t, "portal") ? w : sz * 100.0f;
        if (mirror) y = 2 * axis - y - h;
        o->r = (rect_t){x, y, w, h};
        if (!strcmp(t, "block")) { o->type = 0; o->hb = o->r; }
        else if (!strcmp(t, "spike")) { o->type = 1; o->hb = (rect_t){x + .3f * w, y + (mirror ? 0 : .2f * h), .4f * w, .8f * h}; }
        else if (!strcmp(t, "portal")) { o->type = 2; o->hb = o->r; for (int k = 0; k < NM; k++) if (!strcmp(m, NAMES[k])) o->mode = k; }
        else continue;
        if (x + 500 > s->end) s->end = x + 500;
        s->n++;
    }
}
/* ---------- bot ---------- */
#define HS (1 << 22)
static uint64_t *dead; typedef struct { uint64_t k; int v; } dec_t; static dec_t path[100000]; static int plen;
static uint64_t mix(uint64_t k){k^=k>>33;k*=0xff51afd7ed558ccdULL;k^=k>>33;return k?k:1;}
static int dh(uint64_t k){for(uint64_t i=k&(HS-1);dead[i];i=(i+1)&(HS-1)) if(dead[i]==k) return 1; return 0;}
static void da(uint64_t k){uint64_t i=k&(HS-1);while(dead[i]&&dead[i]!=k)i=(i+1)&(HS-1);dead[i]=k;}
static long run(sim_t *s, int start_dir, long *far)
{
    int idx = 0; bool held = false; reset(s); s->p.dir = start_dir;
    for (;;) {
        pl_t *p = &s->p; bool edge_mode = p->mode == UFO || p->mode == BALL;
        bool decide = ((p->mode == CUBE || p->mode == BALL) && p->grounded) || ((p->mode == SHIP || p->mode == UFO || p->mode == WAVE) && s->tick % 12 == 0);
        in_t in = {false, false};
        if (p->mode == CUBE) held = false;
        if (decide) {
            uint64_t k = mix(((uint64_t)s->tick << 36) ^ ((uint64_t)(uint32_t)(int)(p->y * 2) << 12) ^ (uint64_t)((int)(p->vy * 64) & 0xfff) ^ ((uint64_t)p->mode << 60) ^ ((uint64_t)(p->dir > 0) << 59));
            if (dh(k)) return s->tick;
            if (idx >= plen) { path[plen].k = k; path[plen].v = 0; plen++; }
            int v = path[idx++].v;
            if (edge_mode) in.pressed = v; else held = v;
        }
        in.held = edge_mode ? in.pressed : held;
        tick(s, in);
        if (s->tick > *far) *far = s->tick;
        if (!s->p.alive) return s->tick;
        if (s->done) return -1;
    }
}
static const char *bot(const char *lvl, bool mirror, float axis, int start_dir)
{
    static char out[64]; static sim_t s; long sims = 0, far = 0;
    load(&s, lvl, mirror, axis); memset(dead, 0, HS * 8); plen = 0;
    for (;;) {
        long r = run(&s, start_dir, &far); sims++;
        if (r < 0) { snprintf(out, 64, "completable (%ld attempts)", sims); return out; }
        while (plen && path[plen - 1].v) { da(path[plen - 1].k); plen--; }
        if (!plen || sims > 300000) { snprintf(out, 64, "NOT completable, furthest %.0f%%", 100.0 * far * PT(SCROLL) / s.end); return out; }
        path[plen - 1].v = 1;
    }
}
int main(void)
{
    dead = calloc(HS, 8);
    sim_t s; load(&s, "", 0, 0);
    /* M1 cube arc at 240 Hz */
    reset(&s); s.end = 1e9; float miny = 800; tick(&s, (in_t){1, 1}); 
    while (!s.p.grounded) { tick(&s, (in_t){0, 0}); if (s.p.y < miny) miny = s.p.y; }
    printf("cube: apex %.1f px, airtime %.3f s\n", 800 - miny, s.tick / TR);
    /* M2 UFO single tap from the ground (no corridor needed) */
    reset(&s); s.end = 1e9; s.p.mode = UFO; miny = 800; long apex_t = 0;
    tick(&s, (in_t){1, 1});
    while (!s.p.grounded) { tick(&s, (in_t){1, 0}); if (s.p.y < miny) { miny = s.p.y; apex_t = s.tick; } }
    printf("ufo: one tap rises %.1f px, apex after %.3f s, back on ground after %.3f s (holding does nothing)\n", 800 - miny, apex_t / TR, s.tick / TR);
    /* M3 UFO: taps needed to hover, i.e. tap period that keeps average height */
    for (int period = 30; period <= 90; period += 15) {
        reset(&s); s.end = 1e9; s.p.mode = UFO; float lo = 1e9, hi = -1e9;
        for (int t = 0; t < 2400; t++) { tick(&s, (in_t){0, t % period == 0}); if (t > 1200) { if (s.p.y < lo) lo = s.p.y; if (s.p.y > hi) hi = s.p.y; } }
        printf("ufo tapping every %d ticks (%.0f ms): settles between y %.0f and %.0f (%s)\n", period, period * 1000 / TR, lo, hi, hi >= 799.9f ? "touches the ground" : "airborne");
    }
    /* M4 wave slope */
    reset(&s); s.end = 1e9; s.p.mode = WAVE; float y0 = s.p.y, x0 = s.p.x;
    for (int t = 0; t < 40; t++) tick(&s, (in_t){1, 0});
    printf("wave: held 40 ticks: dx %.2f, dy %.2f (slope %.4f)\n", s.p.x - x0, y0 - s.p.y, (y0 - s.p.y) / (s.p.x - x0));
    /* M5 ball flip across an 850 px corridor */
    reset(&s); s.end = 1e9; s.p.mode = BALL; s.corr = true; s.top = 0; s.bot = 850; tick(&s, (in_t){0, 0});
    tick(&s, (in_t){1, 1}); long tf = s.tick;
    while (!(s.p.grounded && s.p.dir < 0) && s.tick < tf + 2000) tick(&s, (in_t){0, 0});
    printf("ball: floor -> ceiling (750 px of travel) in %.3f s\n", (s.tick - tf) / TR);
    /* M6 ball buffer: press 5 ticks before landing */
    reset(&s); s.end = 1e9; s.p.mode = BALL; s.corr = true; s.top = 0; s.bot = 850; s.p.y = 500; s.p.grounded = false;
    int land = -1; { sim_t c = s; for (int t = 0; t < 400; t++) { tick(&c, (in_t){0, 0}); if (c.p.grounded) { land = t; break; } } }
    for (int t = 0; t < land + 20; t++) tick(&s, (in_t){t == land - 5, t == land - 5});
    printf("ball buffer: click 5 ticks before landing -> gravity %s\n", s.p.dir < 0 ? "flipped (click kept)" : "not flipped (click lost)");
    /* M8 flipped gravity lands on a block's underside */
    load(&s, "block 250 300 2\nblock 350 300 2\nblock 450 300 2\nblock 550 300 2\n", 0, 0); reset(&s); s.end = 1e9; s.p.mode = BALL; s.corr = true; s.top = 0; s.bot = 850;
    s.p.dir = -1; s.p.y = 500; s.p.grounded = false;
    for (int t = 0; t < 200 && !s.p.grounded && s.p.alive; t++) { tick(&s, (in_t){0, 0}); if (t < 3 || !s.p.alive) printf("  t%d y %.1f vy %.3f alive %d n %d o0 %.0f,%.0f %.0fx%.0f\n", t, s.p.y, s.p.vy, s.p.alive, s.n, s.o[0].hb.x, s.o[0].hb.y, s.o[0].hb.w, s.o[0].hb.h); }
    printf("flipped ball under block (block bottom 400): grounded %d at y %.1f (expected 450), alive %d\n", s.p.grounded, s.p.y, s.p.alive);
    /* M9 UFO hover period: tap every N ticks, find N with zero net drift */
    for (int period = 100; period <= 160; period += 10) {
        load(&s, "", 0, 0); reset(&s); s.end = 1e9; s.p.mode = UFO; s.p.y = 400; s.p.grounded = false;
        float start = 0; for (int t = 0; t < 1440; t++) { tick(&s, (in_t){0, t % period == 0}); if (t == 480) start = s.p.y; }
        printf("ufo tap every %d ticks (%.0f ms): drift %+.0f px over 4 s\n", period, period * 1000 / TR, start - s.p.y);
    }
    /* M7 test levels from FEATURES.md, normal and mirrored */
    const char *ufo = "portal 1500 650 2 ufo\nblock 2300 550 2\nblock 2300 650 2\nblock 2300 750 2\nspike 2900 750 2\nportal 3600 650 2 cube\n";
    const char *wave = "portal 1500 350 2 wave\nspike 2200 750 2\nblock 2600 250 2\nblock 3000 550 2\nportal 4000 350 2 cube\n";
    const char *ball = "portal 1500 350 2 ball\nspike 2200 750 2\nspike 2800 0 2\nspike 3400 750 2\nportal 4200 350 2 cube\n";
    const char *names[] = {"ufo", "wave", "ball"}; const char *lv[] = {ufo, wave, ball};
    for (int i = 0; i < 3; i++) printf("test level %-4s: %s\n", names[i], bot(lv[i], 0, 0, 1));
    return 0;
}
