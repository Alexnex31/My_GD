/* Prototype of the plan's simulation core: pure C, no CSFML. */
#ifndef SIM_H
    #define SIM_H
    #include <stdbool.h>
    #include <stddef.h>

    #define TICK_RATE 60.0f
    #define TICK_DT (1.0f / TICK_RATE)
    #define GROUND_Y 850.0f
    #define PLAYER_HALF 50.0f
    #define PLAYER_SCREEN_X 350.0f
    #define SCROLL_PER_TICK 12.5f
    #define CUBE_GRAVITY 1.4f      /* per tick, legacy units for exact parity */
    #define CUBE_JUMP_V 26.0f
    #define CUBE_MAX_VY 43.0f
    #define SHIP_GRAVITY 1.55f
    #define SHIP_THRUST 3.5f
    #define SHIP_MAX_VY 28.0f
    
typedef struct { float x, y, w, h; } rect_t;
typedef enum { OBJ_BLOCK, OBJ_SPIKE, OBJ_PORTAL } obj_type_t;
typedef enum { MODE_CUBE, MODE_SHIP } gamemode_t;
typedef struct { obj_type_t type; rect_t rect, hitbox; gamemode_t portal_mode; bool triggered; } object_t;
typedef struct { float x, y; } vec2_t;
typedef struct { vec2_t pos; float vy; gamemode_t mode; bool grounded, alive; } player_t;
typedef struct { bool active; float top, bottom; } ship_bounds_t;
typedef struct {
    object_t *objects; size_t nb, first_active; float max_w, end_shift;
    player_t p; vec2_t cam; ship_bounds_t bounds; long tick; bool complete;
} sim_t;

typedef struct { int legacy_teleport, legacy_jump_lock, proportional_spikes, new_block_collision, centered_corridor, ticks_per_frame;
    float jump_v; float cube_g; } sim_flags_t;   /* jump_v, cube_g in legacy per-frame units; 0 = default */
extern sim_flags_t g_flags;
int sim_load(sim_t *s, const char *path);
void sim_reset(sim_t *s, float spawn_x, float spawn_y);
void sim_tick(sim_t *s, bool held);
void sim_free(sim_t *s);
#endif
