#include "sim.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

sim_flags_t g_flags = {1, 1, 0, 0, 0, 1, 0.0f, 0.0f};
#define TK ((float)g_flags.ticks_per_frame)

static bool overlap(rect_t a, rect_t b)
{
    return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
}

static int cmp_x(const void *a, const void *b)
{
    const object_t *oa = a, *ob = b;
    return (oa->rect.x > ob->rect.x) - (oa->rect.x < ob->rect.x);
}

int sim_load(sim_t *s, const char *path)
{
    FILE *f = fopen(path, "r");
    char *line = NULL; size_t len = 0, cap = 0; int lineno = 0;
    memset(s, 0, sizeof(*s));
    if (!f) return -1;
    s->end_shift = 100.0f;
    while (getline(&line, &len, f) > 0) {
        char type[16] = {0}, mode[16] = {0}; float x, y; int size;
        lineno++;
        int n = sscanf(line, "%15s %f %f %d %15s", type, &x, &y, &size, mode);
        if (lineno == 1 || n < 4 || size <= 0) continue;   /* legacy header / junk */
        if (s->nb == cap) { cap = cap ? cap * 2 : 64; s->objects = realloc(s->objects, cap * sizeof(object_t)); }
        object_t *o = &s->objects[s->nb];
        memset(o, 0, sizeof(*o));
        if (!strcmp(type, "block")) {
            o->type = OBJ_BLOCK; o->rect = (rect_t){x, y, size * 50.0f, size * 50.0f}; o->hitbox = o->rect;
        } else if (!strcmp(type, "spike")) {
            o->type = OBJ_SPIKE; o->rect = (rect_t){x, y, size * 50.0f, size * 50.0f};
            o->hitbox = g_flags.proportional_spikes ? (rect_t){x + 0.3f * o->rect.w, y + 0.2f * o->rect.h, 0.4f * o->rect.w, 0.8f * o->rect.h}
                                               : (rect_t){x + 30, y + size * 10, 40, 100 - size * 10};
        } else if (!strcmp(type, "portal") && n == 5 && (!strcmp(mode, "ship") || !strcmp(mode, "cube"))) {
            o->type = OBJ_PORTAL; o->rect = (rect_t){x, y, size * 50.0f, size * 100.0f}; o->hitbox = o->rect;
            o->portal_mode = !strcmp(mode, "ship") ? MODE_SHIP : MODE_CUBE;
        } else continue;
        if (x + 500 > s->end_shift) s->end_shift = x + 500;
        if (o->rect.w > s->max_w) s->max_w = o->rect.w;
        s->nb++;
    }
    free(line); fclose(f);
    qsort(s->objects, s->nb, sizeof(object_t), cmp_x);
    return 0;
}

void sim_reset(sim_t *s, float spawn_x, float spawn_y)
{
    s->p = (player_t){.pos = {spawn_x, spawn_y}, .mode = MODE_CUBE, .alive = true};
    s->cam = (vec2_t){0, 0}; s->bounds.active = false; s->tick = 0; s->first_active = 0; s->complete = false;
    for (size_t i = 0; i < s->nb; i++) s->objects[i].triggered = false;
}

/* legacy-compatible camera: integer ceil/floor steps, no clamp (parity) */
static void camera_follow(sim_t *s)
{
    float sy = s->p.pos.y - s->cam.y;
    if (s->p.mode != MODE_CUBE) return;
    if (sy < 200) s->cam.y -= ceilf(200 - sy);
    sy = s->p.pos.y - s->cam.y;
    if (sy > 790 && s->cam.y != 0) s->cam.y -= floorf(790 - sy);
}

static void enter_portal(sim_t *s, object_t *o)
{
    if (o->portal_mode == MODE_SHIP) {
        float cam_new = o->rect.y - 500.0f;
        if (g_flags.legacy_teleport) s->p.pos.y -= cam_new - s->cam.y;
        s->cam.y = cam_new;
        s->bounds = (ship_bounds_t){true, cam_new + 100.0f, cam_new + 950.0f};
        if (g_flags.centered_corridor) {
            float c = o->rect.y + o->rect.h / 2;
            s->bounds.top = c - 425; s->bounds.bottom = c + 425;
            if (s->bounds.bottom > GROUND_Y) { s->bounds.bottom = GROUND_Y; s->bounds.top = GROUND_Y - 850; }
            s->cam.y = s->bounds.top - 100;
        }
    } else {
        s->bounds.active = false;
        s->p.grounded = false;        /* legacy: load_new_player_texture('c') clears allow_jump */
    }
    s->p.mode = o->portal_mode;
}

static float g_prev_y;
static void collide_block_new(player_t *p, const object_t *o)
{
    rect_t outer = {p->pos.x - 50, p->pos.y - 50, 100, 100}, inner = {p->pos.x - 20, p->pos.y - 20, 40, 40};
    float prev_bottom = g_prev_y + 50, prev_top = g_prev_y - 50, top = o->hitbox.y, bottom = o->hitbox.y + o->hitbox.h;
    if (!overlap(outer, o->hitbox)) return;
    if (p->vy <= 0 && prev_bottom <= top + 12.0f) { p->pos.y = top - 50; p->vy = 0; p->grounded = true; return; }
    if (p->mode == MODE_SHIP && p->vy >= 0 && prev_top >= bottom - 12.0f) { p->pos.y = bottom + 50; p->vy = 0; return; }
    if (overlap(inner, o->hitbox)) p->alive = false;
}

static void collide_block_legacy(player_t *p, const object_t *o)
{
    rect_t pb = {p->pos.x - 40, p->pos.y - 40, 80, 90};
    if (!overlap(pb, o->hitbox)) return;
    float pt = pb.y + pb.h - o->hitbox.y, pbm = o->hitbox.y + o->hitbox.h - pb.y, pl = pb.x + pb.w - o->hitbox.x;
    float m = pt; char side = 't';
    if (pbm < m) { m = pbm; side = 'b'; }
    if (pl < m) side = 'l';
    if (side == 't') { p->pos.y = o->hitbox.y - PLAYER_HALF; p->vy = 0; p->grounded = true; return; }
    if (side == 'b' && p->mode == MODE_SHIP) { p->pos.y = o->hitbox.y + o->hitbox.h + PLAYER_HALF; p->vy = 0; return; }
    p->alive = false;
}

void sim_tick(sim_t *s, bool held)
{
    player_t *p = &s->p;
    if (!p->alive || s->complete) return;
    /* input (legacy applies it at the end of the previous frame) */
    if (held && p->mode == MODE_CUBE && p->grounded) p->vy = (g_flags.jump_v > 0 ? g_flags.jump_v : CUBE_JUMP_V) / TK;
    if (held && p->mode == MODE_SHIP) p->vy += SHIP_THRUST / (TK * TK);
    g_prev_y = p->pos.y;
    s->tick++;
    p->pos.x = 350.0f + (float)s->tick * (SCROLL_PER_TICK / TK);
    camera_follow(s);                 /* legacy: camera moves before gravity */
    float g = (p->mode == MODE_CUBE ? (g_flags.cube_g > 0 ? g_flags.cube_g : CUBE_GRAVITY) : SHIP_GRAVITY) / (TK * TK), mx = (p->mode == MODE_CUBE ? CUBE_MAX_VY : SHIP_MAX_VY) / TK;
    p->vy -= g; if (p->vy > mx) p->vy = mx; if (p->vy < -mx) p->vy = -mx;
    p->pos.y -= p->vy;
    if (s->bounds.active && p->mode == MODE_SHIP) {
        if (p->pos.y <= s->bounds.top + PLAYER_HALF) { p->pos.y = s->bounds.top + PLAYER_HALF; p->vy = 0; }
        else if (p->pos.y + PLAYER_HALF > s->bounds.bottom) { p->pos.y = s->bounds.bottom - PLAYER_HALF; p->vy = 0; }
    }
    if ((float)s->tick * (SCROLL_PER_TICK / TK) >= s->end_shift) { s->complete = true; return; }
    p->grounded = false;
    /* ground plane, legacy box */
    if (p->pos.y + PLAYER_HALF > GROUND_Y) { p->pos.y = GROUND_Y - PLAYER_HALF; p->vy = 0; p->grounded = true; }
    rect_t outer = {p->pos.x - 50, p->pos.y - 50, 100, 100};
    while (s->first_active < s->nb && s->objects[s->first_active].rect.x + s->max_w < outer.x - 50) s->first_active++;
    /* legacy order: all blocks, then spikes, then portals */
    for (int pass = 0; pass < 3 && p->alive; pass++)
        for (size_t i = s->first_active; i < s->nb && p->alive; i++) {
            object_t *o = &s->objects[i];
            if (o->rect.x > p->pos.x + 60) break;
            if ((int)o->type != pass) continue;
            outer = (rect_t){p->pos.x - 50, p->pos.y - 50, 100, 100};
            if (pass == 0) { if (g_flags.new_block_collision) collide_block_new(p, o); else collide_block_legacy(p, o); }
            else if (pass == 1 && overlap(outer, o->hitbox)) p->alive = false;
            else if (pass == 2 && overlap(outer, o->hitbox)) {
                if (!o->triggered) { o->triggered = true; enter_portal(s, o); }
                else if (g_flags.legacy_jump_lock && o->portal_mode == MODE_CUBE) p->grounded = false;
            }
        }
}

void sim_free(sim_t *s) { free(s->objects); }
