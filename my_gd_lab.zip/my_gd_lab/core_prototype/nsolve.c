/* Bot for the new core: pure C, no window, no GPU. */
#include "sim.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#define MAXD 40000
#define HSIZE (1 << 22)
typedef struct { uint64_t key; int val; } dec_t;
static dec_t path[MAXD]; static int plen; static uint64_t *dead;
static uint64_t mix(uint64_t k){k^=k>>33;k*=0xff51afd7ed558ccdULL;k^=k>>33;return k?k:1;}
static int dead_has(uint64_t k){for(uint64_t i=k&(HSIZE-1);dead[i];i=(i+1)&(HSIZE-1)) if(dead[i]==k) return 1; return 0;}
static void dead_add(uint64_t k){uint64_t i=k&(HSIZE-1);while(dead[i]&&dead[i]!=k)i=(i+1)&(HSIZE-1);dead[i]=k;}
static uint64_t key(sim_t *s){ int32_t y=(int32_t)(s->p.pos.y*2), vy=(int32_t)(s->p.vy*8);
    return mix(((uint64_t)s->tick<<40)^((uint64_t)(uint32_t)y<<16)^(uint64_t)(uint16_t)vy^((uint64_t)s->p.mode<<62)); }
static long simulate(sim_t *s, int ship_step, long *far)
{
    int idx = 0, hold = 0;
    sim_reset(s, 350, 800);
    s->p.grounded = true;
    for (;;) {
        int decide = (s->p.mode == MODE_CUBE && s->p.grounded) || (s->p.mode == MODE_SHIP && s->tick % ship_step == 0);
        if (s->p.mode == MODE_CUBE) hold = 0;
        if (decide) {
            uint64_t k = key(s);
            if (dead_has(k)) return s->tick;
            if (idx >= plen) { path[plen].key = k; path[plen].val = 0; plen++; }
            hold = path[idx++].val;
        }
        sim_tick(s, hold);
        if (s->tick > *far) *far = s->tick;
        if (!s->p.alive) return s->tick;
        if (s->complete) return -1;
    }
}
int main(int argc, char **argv)
{
    /* usage: nsolve level teleport lock propspikes newcoll centered ticks_per_frame [jump_v [cube_g]]
       (jump_v and cube_g in legacy per-frame units: 26 and 1.4 are the defaults) */
    sim_t s;
    int f[6]; for (int i = 0; i < 6; i++) f[i] = atoi(argv[2 + i]);
    g_flags = (sim_flags_t){f[0], f[1], f[2], f[3], f[4], f[5], argc > 8 ? atof(argv[8]) : 0, argc > 9 ? atof(argv[9]) : 0};
    sim_load(&s, argv[1]);
    dead = calloc(HSIZE, 8); plen = 0;
    long sims = 0, far = 0;
    for (;;) {
        long r = simulate(&s, 3 * f[5], &far); sims++;
        if (r < 0) { printf("OK   (%ld attempts)", sims); break; }
        while (plen > 0 && path[plen - 1].val == 1) { dead_add(path[plen - 1].key); plen--; }
        if (plen == 0) { printf("IMPOSSIBLE (furthest %.0f%%)", 100.0 * far * 12.5 / f[5] / s.end_shift); break; }
        if (sims > 400000) { printf("GAVE UP (furthest %.0f%%)", 100.0 * far * 12.5 / f[5] / s.end_shift); break; }
        path[plen - 1].val = 1;
    }
    printf("\n");
    return 0;
}
