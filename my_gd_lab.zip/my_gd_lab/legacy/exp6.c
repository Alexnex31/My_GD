/* E6: first-attempt vs retry timing window (level3 first spike) */
#include "harness.h"
static int survives(gd_t *gd, int jf, int retry)
{
    level_t *lv = start_level(gd);
    int ok = 1;
    if (retry) lv->player->pos = (sfVector2f){350, 790};
    for (int f = 0; f < 150; f++) {       /* past the first spike only */
        legacy_frame(gd, lv, f == jf);
        if (lv->curr_attempts != 1) { ok = 0; break; }
    }
    free_level(lv);
    return ok;
}
int main(void)
{
    gd_t *gd = create_gd();
    gd->selected_level = 3;                /* first spike at x=2000 */
    for (int r = 0; r < 2; r++) {
        int lo = -1, hi = -1;
        for (int jf = 60; jf < 150; jf++)
            if (survives(gd, jf, r)) { if (lo < 0) lo = jf; hi = jf; }
        printf("%s spawn: jumping on frames %d..%d clears the first spike of level3 (%d-frame window)\n",
               r ? "retry (350,790)" : "first attempt (400,750)", lo, hi, hi - lo + 1);
    }
    return 0;
}
