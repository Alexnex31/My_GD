/* E2: ship portal teleport and boundary leak (level7) */
#include "harness.h"
int main(void)
{
    gd_t *gd = create_gd();
    gd->selected_level = 7;
    level_t *lv = start_level(gd);
    player_t *p = lv->player;
    void *last = NULL; int allocs = 0, f;
    for (f = 0; f < 400 && lv->curr_attempts == 1; f++) {
        float py = p->pos.y, ys = lv->objects->ground->pos.y;
        char gm = p->gamemode;
        legacy_frame(gd, lv, 0);
        if (lv->objects->portal_blocks != last) {
            if (lv->objects->portal_blocks) allocs++;
            printf("frame %3d: portal_blocks=%p mode %c->%c  player y %.1f -> %.1f (dy %.1f)  ground y %.1f -> %.1f (dy %.1f)\n",
                f, (void*)lv->objects->portal_blocks, gm, p->gamemode, py, p->pos.y, p->pos.y - py, ys,
                lv->objects->ground->pos.y, lv->objects->ground->pos.y - ys);
            last = lv->objects->portal_blocks;
        }
    }
    printf("boundary lists allocated for ONE ship portal: %d (1 expected, %d leaked)\n", allocs, allocs - 1);
    return 0;
}
