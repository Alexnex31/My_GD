/* E1: spawn difference and jump arc */
#include "harness.h"
int main(void)
{
    gd_t *gd = create_gd();
    gd->selected_level = 3;
    level_t *lv = start_level(gd);
    player_t *p = lv->player;
    int f;
    /* E1a: first-attempt spawn: how long until grounded */
    for (f = 0; f < 30 && p->allow_jump != 'y'; f++) legacy_frame(gd, lv, 0);
    printf("first attempt: spawn (400,750) grounded after %d frames at x=%.1f y=%.1f\n", f, p->pos.x, p->pos.y);
    /* E1b: jump arc from ground */
    float y0 = p->pos.y, miny = y0; int air = 0; float shift0 = lv->shift;
    legacy_frame(gd, lv, 1);
    do { legacy_frame(gd, lv, 0); air++; if (p->pos.y < miny) miny = p->pos.y; } while (p->allow_jump != 'y' && air < 200);
    printf("jump: apex %.1f px, airtime %d frames (%.3f s), horizontal distance %.1f px\n", y0 - miny, air + 1, (air + 1) / 60.0, lv->shift - shift0);
    /* E1c: retry spawn */
    player_dead(p, lv, lv->objects, gd);
    for (f = 0; f < 30 && p->allow_jump != 'y'; f++) legacy_frame(gd, lv, 0);
    printf("retry: spawn (350,790) grounded after %d frames at x=%.1f y=%.1f\n", f, p->pos.x, p->pos.y);
    printf("level_end=%.1f frames to finish=%.0f\n", lv->level_end, lv->level_end / 12.5);
    return 0;
}
