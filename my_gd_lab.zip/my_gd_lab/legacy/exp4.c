/* E4: best percentage truncation */
#include "harness.h"
void read_level_info(char *filepath, int *level_num, int *attempts, float *best);
int main(void)
{
    FILE *lf = fopen("levels/level9", "w");
    fputs("9 5 47.830000\nspike 3000 750 2\n", lf); fclose(lf);
    gd_t *gd = create_gd();
    gd->selected_level = 9;
    level_t *lv = start_level(gd);
    int n, a; float b;
    read_level_info("levels/level9", &n, &a, &b);
    printf("file says best=47.83 -> level loader best=%.2f, level list best=%.2f\n", lv->best, b);
    char **arr = my_str_to_word_array("9 5 47.830000\n");
    printf("my_str_to_word_array(\"9 5 47.830000\") ->");
    for (int i = 0; arr[i]; i++) printf(" [%s]", arr[i]);
    printf("\n");
    lv->percent = 12.5f; lv->best = 47.83f;
    rewrite_level(lv, gd);
    FILE *f = fopen("levels/level9", "r"); char line[100]; fgets(line, 100, f); fclose(f);
    printf("after rewrite_level: first line = %s", line);
    remove("levels/level9");
    return 0;
}
