#include "mygd.h"
gd_t *create_gd(void);
void jump(level_t *level, gd_t *gd);
/* one legacy frame, same order as the game: physics, collisions, then input */
static inline void legacy_frame(gd_t *gd, level_t *lv, int hold)
{
    apply_physics(gd, lv, lv->objects);
    check_collisions(gd, lv, lv->objects);
    if (hold)
        jump(lv, gd);
}
void player_dead(player_t *player, level_t *level, object_list_t *obj, gd_t *gd);
