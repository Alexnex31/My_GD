/* Bot: proves each level is beatable with the legacy physics; writes solN.txt */
#include "harness.h"
#include <stdint.h>
/* DFS over input decisions with a dead-state memo.
   Cube: decide at every grounded frame. Ship: decide every SHIP_STEP frames. */
#define MAXD 20000
#define HSIZE (1 << 22)
typedef struct { uint64_t key; int val; } dec_t;
static dec_t path[MAXD]; static int plen;
static uint64_t *dead;
static int SHIP_STEP = 3, RETRY_SPAWN = 0;
static uint64_t mix(uint64_t k){k^=k>>33;k*=0xff51afd7ed558ccdULL;k^=k>>33;return k?k:1;}
static int dead_has(uint64_t k){for(uint64_t i=k&(HSIZE-1);dead[i];i=(i+1)&(HSIZE-1)) if(dead[i]==k) return 1; return 0;}
static void dead_add(uint64_t k){uint64_t i=k&(HSIZE-1);while(dead[i]&&dead[i]!=k)i=(i+1)&(HSIZE-1);dead[i]=k;}
static uint64_t state_key(int f, player_t *p){
    int32_t y = (int32_t)(p->pos.y * 2), vy = (int32_t)(p->vy * 2);
    return mix(((uint64_t)f << 40) ^ ((uint64_t)(uint32_t)y << 16) ^ (uint64_t)(uint16_t)vy ^ ((uint64_t)p->gamemode << 60));
}
/* returns -1 on completion, else frame of death */
static char holds[20000];
static int simulate(gd_t *gd, int *frames_out)
{
    level_t *lv = start_level(gd);
    player_t *p = lv->player;
    int idx = 0, f, res = -2;
    if (RETRY_SPAWN) p->pos = (sfVector2f){350, 790};
    for (f = 0; f < 20000; f++) {
        apply_physics(gd, lv, lv->objects);
        check_collisions(gd, lv, lv->objects);
        if (lv->curr_attempts != 1) { res = f; break; }
        if (lv->level_completed == 'y') { res = -1; break; }
        int decide = (p->gamemode == 'c' && p->allow_jump == 'y') || (p->gamemode == 'p' && f % SHIP_STEP == 0);
        static int hold = 0;
        if (p->gamemode == 'c') hold = 0;
        if (decide) {
            uint64_t k = state_key(f, p);
            if (dead_has(k)) { res = f; break; }
            if (idx >= plen) { path[plen].key = k; path[plen].val = 0; plen++; }
            hold = path[idx].val; idx++;
        }
        holds[f] = hold;
        if (hold) jump(lv, gd);
    }
    *frames_out = f;
    free_level(lv);
    return res;
}
int main(int argc, char **argv)
{
    gd_t *gd = create_gd();
    gd->selected_level = atoi(argv[1]);
    RETRY_SPAWN = argc > 2 && argv[2][0] == 'r';
    dead = calloc(HSIZE, sizeof(uint64_t));
    long sims = 0; int frames = 0, far = 0;
    while (1) {
        int r = simulate(gd, &frames); sims++;
        if (frames > far) far = frames;
        if (r == -1) {
            int jumps = 0; for (int i = 0; i < plen; i++) jumps += path[i].val;
            printf("level %d (%s spawn): COMPLETABLE, found after %ld simulated attempts, %d frames, %d input decisions held\n",
                gd->selected_level, RETRY_SPAWN ? "retry" : "first-attempt", sims, frames, jumps);
            char fn[64]; snprintf(fn, 64, "sol%d.txt", gd->selected_level);
            FILE *o = fopen(fn, "w"); for (int i = 0; i <= frames; i++) fputc('0' + holds[i], o); fclose(o);
            return 0;
        }
        while (plen > 0 && path[plen - 1].val == 1) { dead_add(path[plen - 1].key); plen--; }
        if (plen == 0 || sims > 300000) {
            printf("level %d (%s spawn): %s after %ld attempts, furthest frame reached %d\n", gd->selected_level,
                RETRY_SPAWN ? "retry" : "first-attempt", plen == 0 ? "IMPOSSIBLE (search exhausted)" : "gave up", sims, far);
            return 0;
        }
        path[plen - 1].val = 1; // flip
        /* truncate: decisions after this one are re-discovered */
    }
}
