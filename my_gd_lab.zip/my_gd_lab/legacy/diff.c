/* Differential test: legacy code vs core_prototype on perturbed bot scripts */
#include "harness.h"
#define player_t ns_player_t
#include "../core_prototype/sim.h"
#undef player_t
/* Run the same per-frame input script through the legacy code and the new core. */
typedef struct { int end; int completed; float max_dy; int first_div; } run_t;
static run_t run_legacy(gd_t *gd, const char *h, int n, float *ys)
{
    level_t *lv = start_level(gd);
    run_t r = {-1, 0, 0, -1};
    lv->player->pos = (sfVector2f){350, 790};
    for (int f = 0; f < n; f++) {
        apply_physics(gd, lv, lv->objects);
        check_collisions(gd, lv, lv->objects);
        if (lv->curr_attempts != 1) { r.end = f; break; }
        if (lv->level_completed == 'y') { r.end = f; r.completed = 1; break; }
        ys[f] = lv->player->pos.y - lv->yshift;
        if (h[f] == '1') jump(lv, gd);
    }
    free_level(lv);
    return r;
}
static run_t run_new(sim_t *s, const char *h, int n, const float *ys, int legacy_end)
{
    run_t r = {-1, 0, 0, -1};
    sim_reset(s, 350, 790);
    for (int f = 0; f < n; f++) {
        sim_tick(s, f > 0 && h[f - 1] == '1');
        if (!s->p.alive) { r.end = f; break; }
        if (s->complete) { r.end = f; r.completed = 1; break; }
        if (legacy_end < 0 || f < legacy_end) {
            float d = fabsf(s->p.pos.y - ys[f]);
            if (d > r.max_dy) r.max_dy = d;
            if (d > 0.01f && r.first_div < 0) r.first_div = f;
        }
    }
    return r;
}
int main(void)
{
    gd_t *gd = create_gd();
    static char h[20000]; static float ys[20000];
    srand(42);
    for (int l = 1; l <= 7; l++) {
        char path[64]; sim_t s;
        snprintf(path, 64, "levels/level%d", l);
        sim_load(&s, path);
        gd->selected_level = l;
        FILE *f = fopen((snprintf(path, 64, "sol%d.txt", l), path), "r");
        int n = fread(h, 1, sizeof(h) - 1, f); fclose(f);
        int runs = 0, agree = 0, bothwin = 0; float worst = 0; int worst_div = -1;
        for (int k = 0; k < 400; k++) {
            char hh[20000]; memcpy(hh, h, n);
            if (k > 0) {                                /* perturb the winning script */
                int nflip = 1 + rand() % 4;
                for (int j = 0; j < nflip; j++) { int at = rand() % n, len = 1 + rand() % 30;
                    for (int t = at; t < at + len && t < n; t++) hh[t] = (rand() % 2) ? '1' : '0'; }
            }
            run_t a = run_legacy(gd, hh, n + 5, ys);
            run_t b = run_new(&s, hh, n + 5, ys, a.end);
            runs++;
            if (a.end == b.end && a.completed == b.completed) agree++;
            else if (worst_div < 0) { worst_div = k; printf("  level %d script %d: legacy %s at frame %d, new %s at frame %d (y diverged first at %d)\n",
                l, k, a.completed ? "completes" : "dies", a.end, b.completed ? "completes" : "dies", b.end, b.first_div); }
            if (a.completed && b.completed) bothwin++;
            if (b.max_dy > worst) worst = b.max_dy;
        }
        printf("level %d: %d/%d scripts identical outcome (%d completions), max |y diff| %.4f px\n", l, agree, runs, bothwin, worst);
        sim_free(&s);
    }
    return 0;
}
