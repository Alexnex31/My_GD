/* E3: wide-block fall-through */
#include "harness.h"
int main(void)
{
    FILE *lf = fopen("levels/level8", "w");
    fputs("8 0 0.000000\nblock 1000 700 8\n", lf); fclose(lf);   /* one 400px-wide platform */
    gd_t *gd = create_gd();
    gd->selected_level = 8;
    for (int jf = 0; jf < 60; jf++) {
        level_t *lv = start_level(gd);
        player_t *p = lv->player;
        int landed = -1, fell = -1;
        for (int f = 0; f < 200 && lv->curr_attempts == 1; f++) {
            legacy_frame(gd, lv, f == jf);
            float left = lv->objects->blocks[0]->pos.x;
            if (landed < 0 && p->allow_jump == 'y' && p->pos.y < 700) landed = f;
            if (landed >= 0 && fell < 0 && p->pos.y > 651 && left + 400 > p->pos.x - 40) {
                fell = f;
                printf("jump at frame %d: landed on the 400px block at frame %d, then fell through at frame %d "
                       "while block spans screen x %.1f..%.1f and player center is at x %.1f\n",
                       jf, landed, f, left, left + 400, p->pos.x);
            }
        }
        free_level(lv);
        if (fell >= 0) break;
    }
    remove("levels/level8");
    return 0;
}
